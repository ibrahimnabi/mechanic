import React, { Component } from "react";
import { Text, View } from "react-native";

export default class EditSession extends Component {
  render() {
    return (
      <View>
        <Text> EditSession </Text>
      </View>
    );
  }
}
