import React, { Component } from "react";
import { Text, View, Linking, ScrollView, Image } from "react-native";
import { connect } from "react-redux";
import { TouchableOpacity } from "react-native-gesture-handler";
import { Actions } from "react-native-router-flux";
import Firebase from "../Firebase/Firebase";
import * as Location from "expo-location";
import * as TaskManager from "expo-task-manager";
const LOCATION_TASK_NAME = "background-location-task";
let key = "";

class CustomerMatched extends Component {
  componentDidMount = async () => {
    key = this.props.currentSession.key;
    const { status } = await Location.requestPermissionsAsync();
    if (status === "granted") {
      await Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
        accuracy: Location.Accuracy.Balanced,
      });
    }
  };
  openLocation = async () => {
    const location = this.props.currentSession.val().location;
    Linking.openURL(
      `http://www.google.com/maps/place/${location.lat},${location.lng}`
    );
  };
  openPhone = async () => {
    Linking.openURL(`tel:${this.props.currentCustomer.phone}`);
  };
  endSession = async () => {
    await TaskManager.unregisterTaskAsync(LOCATION_TASK_NAME);
    Actions.endSession();
  };
  render() {
    console.log(this.props.currentSession);
    return (
      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        <View
          style={{
            flexDirection: "row",
            width: "100%",
            padding: 10,
            paddingTop: 40,
            borderBottomColor: "rgba(0,0,0,0.2)",
            borderBottomWidth: 1,
            marginBottom: 50,
          }}
        >
          <Text style={{ fontSize: 20, fontWeight: "bold" }}>
            Customer Matched
          </Text>
        </View>
        <View style={{ alignSelf: "center", width: "90%", marginBottom: 20 }}>
          <Image
            style={{
              width: 130,
              height: 130,
              resizeMode: "cover",
              borderRadius: 100,
              marginRight: 20,
              marginBottom: 20,
            }}
            source={{
              uri: this.props.currentCustomer
                ? this.props.currentCustomer.photo_url
                  ? this.props.currentCustomer.photo_url
                  : "https://www.eguardtech.com/wp-content/uploads/2018/08/Network-Profile.png"
                : "https://www.eguardtech.com/wp-content/uploads/2018/08/Network-Profile.png",
            }}
          ></Image>
          <Text style={{ fontWeight: "bold", fontSize: 16 }}>
            Name of the Customer:
          </Text>
          <Text style={{ fontSize: 16 }}>
            {this.props.currentCustomer.name}
          </Text>
        </View>
        <View style={{ alignSelf: "center", width: "90%", marginBottom: 20 }}>
          <Text style={{ fontWeight: "bold", fontSize: 16 }}>Car:</Text>
          <Text style={{ fontSize: 16 }}>
            {this.props.currentSession.val().vehicle.company +
              " " +
              this.props.currentSession.val().vehicle.name +
              " " +
              this.props.currentSession.val().vehicle.model}
          </Text>
        </View>
        <View style={{ alignSelf: "center", width: "90%", marginBottom: 20 }}>
          <Text style={{ fontWeight: "bold", fontSize: 16 }}>
            Car Registration Number:
          </Text>
          <Text style={{ fontSize: 16 }}>
            {this.props.currentSession.val().vehicle.regNum}
          </Text>
        </View>
        <View style={{ alignSelf: "center", width: "90%", marginBottom: 20 }}>
          <Text style={{ fontWeight: "bold", fontSize: 16 }}>Car Color:</Text>
          <Text style={{ fontSize: 16 }}>
            {this.props.currentSession.val().vehicle.color}
          </Text>
        </View>

        <TouchableOpacity
          style={{
            alignSelf: "center",
            width: "90%",
            padding: 10,
            borderRadius: 40,
            backgroundColor: "#FF4A4A",
            marginTop: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={this.openLocation}
        >
          <Text style={{ color: "white", fontSize: 16 }}>Open Location</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            alignSelf: "center",
            width: "90%",
            padding: 10,
            borderRadius: 40,
            backgroundColor: "#FF4A4A",
            marginTop: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={this.openPhone}
        >
          <Text style={{ color: "white", fontSize: 16 }}>Call Customer</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            alignSelf: "center",
            width: "90%",
            padding: 10,
            borderRadius: 40,
            backgroundColor: "#FF4A4A",
            marginTop: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={Actions.sessionChat}
        >
          <Text style={{ color: "white", fontSize: 16 }}>
            Message the Customer
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            alignSelf: "center",
            width: "90%",
            padding: 10,
            borderRadius: 40,
            backgroundColor: "#FF4A4A",
            marginTop: 20,
            alignItems: "center",
            justifyContent: "center",
          }}
          onPress={this.endSession}
        >
          <Text style={{ color: "white", fontSize: 16 }}>End Session</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }
}
export default connect((state) => state)(CustomerMatched);

TaskManager.defineTask(LOCATION_TASK_NAME, ({ data, error }) => {
  if (error) {
    console.log(error);
    return;
  }
  if (data) {
    const { locations } = data;
    Firebase.updateLocation(key, locations);
  }
});
