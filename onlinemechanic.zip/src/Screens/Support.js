import React, { Component } from "react";
import {
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Dimensions,
  TextInput,
  KeyboardAvoidingView,
} from "react-native";
import { Ionicons, FontAwesome } from "@expo/vector-icons";
import { Actions } from "react-native-router-flux";
import { connect } from "react-redux";
import Firebase from "../Firebase/Firebase";

class Support extends Component {
  state = {
    messages: [],
    message: "",
  };
  componentDidMount = async () => {
    const messages = await Firebase.getSupportMessages(this.props.mechanic.uid);
    this.setState(
      {
        messages,
      },
      () => {
        Firebase.listenToSupportMessages(
          this.props.mechanic.uid,
          (response) => {
            const message = response.val();
            let messageAlreadyExists = false;
            this.state.messages.forEach((element) => {
              if (element.key == message.key) {
                messageAlreadyExists = true;
              }
            });
            if (!messageAlreadyExists) {
              this.setState({
                messages: [...this.state.messages, message],
              });
            }
          },
          (err) => console.log(err)
        );
      }
    );
  };
  sendMessage = async () => {
    this.setState({
      message: "",
    });
    await Firebase.addSupportMessage(
      this.props.mechanic.uid,
      this.state.message
    );
  };
  render() {
    return (
      <KeyboardAvoidingView behavior="height">
        <View style={styles.navbar}>
          <TouchableOpacity onPress={Actions.pop}>
            <Ionicons name="ios-arrow-round-back" size={35}></Ionicons>
          </TouchableOpacity>
          <Text style={styles.navbarTitle}>Support</Text>
        </View>

        <FlatList
          style={{
            height: Dimensions.get("window").height * 0.78,
            backgroundColor: "rgba(0,0,0,0.02)",
          }}
          key={(e, i) => i + ""}
          data={this.state.messages}
          renderItem={({ item }) => {
            return (
              <View
                style={{
                  marginVertical: 5,
                  padding: 10,
                  marginLeft: 10,
                  marginRight: 10,
                  backgroundColor:
                    item.from == this.props.mechanic.uid
                      ? "rgba(255,255,255,1)"
                      : "rgba(255,0,0,0.1)",
                  maxWidth: "50%",
                  alignSelf:
                    item.from == this.props.mechanic.uid
                      ? "flex-end"
                      : "flex-start",
                  borderRadius: 5,
                }}
              >
                <Text
                  style={{
                    fontSize: 14,
                  }}
                >
                  {item.message}
                </Text>
                <Text
                  style={{
                    fontSize: 10,
                    color: "rgba(0,0,0,0.4)",
                    width: "100%",
                    marginTop: 5,
                  }}
                >
                  {item.time}
                </Text>
              </View>
            );
          }}
        ></FlatList>
        <View
          style={{
            flexDirection: "row",
            backgroundColor: "#FF4A4A",
            alignItems: "center",
            justifyContent: "space-evenly",
            width: "100%",
            height: Dimensions.get("window").height * 0.1,
          }}
        >
          <TextInput
            onChangeText={(text) => {
              this.setState({
                message: text,
              });
            }}
            value={this.state.message}
            placeholderTextColor="black"
            placeholder="Enter Message"
            multiline
            style={{
              width: "70%",
              backgroundColor: "white",
              borderRadius: 5,
              padding: 10,
              textAlignVertical: "top",
            }}
          ></TextInput>
          <TouchableOpacity onPress={this.sendMessage}>
            <FontAwesome name="send" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  navbar: {
    padding: 10,
    paddingTop: 40,
    borderBottomColor: "rgba(0,0,0,0.2)",
    borderBottomWidth: 1,
    flexDirection: "row",
  },
  navbarTitle: {
    flex: 1,
    fontSize: 20,
    paddingLeft: 30,
  },
});
export default connect((state) => state)(Support);
