import React, { Component } from "react";
import { Text, View } from "react-native";

export default class EditServices extends Component {
  render() {
    return (
      <View>
        <Text> EditServices </Text>
      </View>
    );
  }
}
